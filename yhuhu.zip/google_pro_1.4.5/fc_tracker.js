/*
 * FC Tracker — isolated-world collector (chay trong frame Arkose, SONG SONG voi yescap/omo/tay). OBSERVE-ONLY.
 *
 * === Kien truc (validated theo Get_Dataset) ===
 * 3 frame arkose khac nhau: ENFORCEMENT parse /fc/gfct+/fc/ca -> variant (theo N); GAME frame fetch
 * /rtig/image?challenge=N -> anh (theo N) + bat click -> index. variant KHONG bao gio co san o game frame.
 * -> JOIN variant<->anh bang KEY challenge=N (integer chung ca 2 phia), DEFER join toi luc FLUSH (cuoi
 *    challenge map {N->variant} da du) -> KHONG race, KHONG mislabel, khong can PENDING/backfill.
 *
 * Luong:
 *   - variant {n,v}  : tich luy variantByN[n]=v (overwrite giu current). Relay sang moi frame qua SW (FIFO).
 *   - image {n,b64}  : set curN=n, curImage. netClicks ve 0 moi anh moi. N tut ve (n<curN) = challenge MOI
 *                      -> clearQueue (phan doan, khong can "reset" -> tranh bug reset-per-wave).
 *   - click          : dem right-arrow (index = netClicks, khop h=solution.objects[0] cua yescap) / tile.
 *   - submit         : buffer {n:curN, image, index, src} (CHUA gan variant).
 *   - solved         : FLUSH -> moi record join variantByN[rec.n]; gui record co variant, drop N thieu.
 *
 * index=netClicks: yescap click right-arrow DUNG h lan tu vi tri 0 = dap an 0-based (khop MITM).
 */
(() => {
  "use strict";
  let curN = -1, curImage = null, imgFromHook = false, nCells = 0, netClicks = 0, queue = [], flushed = false, lastAct = 0, doneStale = false;
  const variantByN = {}; // N -> variant (tich luy; join luc flush)
  const DBG = true; // bat de F12 xem real-time; tat khi phat that
  const dlog = (...a) => { if (DBG) { try { console.log("%c[fc-tracker]%c", "color:#2fe0c8;font-weight:bold", "", ...a); } catch (e) {} } };
  dlog("loaded @", location.href.slice(0, 90));

  function touch() { try { lastAct = Date.now(); } catch (e) {} }
  // Sang challenge moi -> flush dot vua xong TRUOC khi xoa, NHUNG chi khi co bang chung SOLVED (text terminal
  // con am o frame -> solved->chuoi). reload/abandon (fail -> challenge moi cung restart N=0) KHONG co text
  // terminal -> drop, tranh POST dap an SAI thanh verified:true.
  function clearQueue(reason) {
    if (queue.length && !flushed && domMatch() && !doneStale) { dlog("clearQueue (" + reason + ") solved-flush=" + queue.length); doFlush(); }
    queue = []; netClicks = 0; flushed = false; try { doneStale = domMatch(); } catch (e) {}
  }
  // Lock variant VAO record theo dung N ngay khi biet -> immune voi ghi de cua challenge sau (chung N).
  function setVariant(n, v) { variantByN[n] = v; for (const r of queue) if (r.n === n && !r.variant) r.variant = v; }
  function backfillAll() { for (const r of queue) if (!r.variant && variantByN[r.n]) r.variant = variantByN[r.n]; }

  // ---------- cross-frame relay (SW only = 1 kenh FIFO, tranh reorder) + handshake replay whole map ----------
  const relay = (m) => { try { chrome.runtime.sendMessage(Object.assign({ action: "fc_sync" }, m)); } catch (e) {} };
  try {
    chrome.runtime.onMessage.addListener((m) => {
      if (!m || m.action !== "fc_sync") return;
      if (m.t === "variant" && m.variant && typeof m.n === "number") setVariant(m.n, m.variant);
      else if (m.t === "map" && m.map) { for (const k in m.map) variantByN[k] = m.map[k]; backfillAll(); dlog("map <- replay (" + Object.keys(m.map).length + ")"); }
      else if (m.t === "solved") { if (!flushed && queue.length && domMatch() && !doneStale) { dlog("solved <- sw"); doFlush(); } } // gate: relay tre (SW cold) khong flush nham challenge sau
    });
  } catch (e) {}
  try { chrome.runtime.sendMessage({ action: "fc_sync_req" }); } catch (e) {} // luc load: xin whole map (frame vao tre)

  // ---------- tin hieu tu MAIN hook (cung frame) ----------
  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || !d.__fcq) return;
    if (d.type === "variant") {
      if (d.variant && typeof d.n === "number") { setVariant(d.n, d.variant); relay({ t: "variant", n: d.n, variant: d.variant }); dlog("variant N=" + d.n + " -> " + d.variant); }
    } else if (d.type === "image") {
      const n = (typeof d.n === "number") ? d.n : null;
      if (n != null && curN >= 0 && n < curN) clearQueue("N-rollover " + curN + "->" + n); // N tut ve = challenge MOI
      else if (flushed && d.b64 !== curImage) clearQueue("post-flush new image");           // da flush -> anh moi = dot moi
      else if (n != null && d.b64 !== curImage && queue.some((q) => q.n === n)) clearQueue("wave-redo N=" + n); // anh moi cung N da co record = fail retry (wave tien luon tang N) -> bo wave SAI
      if (d.b64 !== curImage) netClicks = 0;                                                 // wave moi -> carousel ve 0
      if (n != null) curN = n;
      curImage = d.b64; imgFromHook = true; sizeOfB64(d.b64); touch();
      dlog("image N=" + curN + " (" + (d.b64 ? d.b64.length : 0) + "b)");
    } else if (d.type === "solved") {
      doFlush(); relay({ t: "solved" });
    }
  });

  function sizeOfB64(b64) {
    try { const im = new Image(); im.onload = () => { if (im.naturalWidth) nCells = Math.floor(im.naturalWidth / 200) || nCells; }; im.src = "data:image/jpeg;base64," + b64; } catch (e) {}
  }

  // ---------- DOM fallback anh (khi hook khong bat duoc) ----------
  const IMG_SELS = ["#game_challengeItem_image", "#game_answerFrame_children_challengeImage", ".key-frame-image", 'img[src*="rtig/image"]', "#game_children_challenge a"];
  function imgUrlOf(el) {
    if (!el) return null;
    if (el.tagName === "IMG") return el.currentSrc || el.src || null;
    const m = /url\(["']?(.+?)["']?\)/.exec((getComputedStyle(el).backgroundImage) || "");
    return m ? m[1] : null;
  }
  function refreshDomImage() {
    if (imgFromHook) return;
    try {
      for (const s of IMG_SELS) {
        const el = document.querySelector(s);
        const url = imgUrlOf(el);
        if (!url) continue;
        const nm = /[?&]challenge=(\d+)/.exec(url); if (nm) curN = parseInt(nm[1], 10);
        const im = new Image();
        im.crossOrigin = "anonymous";
        im.onload = () => {
          try {
            if (imgFromHook || !im.naturalWidth) return;
            const cv = document.createElement("canvas");
            cv.width = im.naturalWidth; cv.height = im.naturalHeight;
            cv.getContext("2d").drawImage(im, 0, 0);
            const b64 = (cv.toDataURL("image/jpeg").split(",")[1]) || null;
            if (b64) { curImage = b64; nCells = Math.floor(im.naturalWidth / 200) || nCells; }
          } catch (e) {}
        };
        im.src = url;
        return;
      }
    } catch (e) {}
  }

  // ---------- selector click (khop dung driver yescap) ----------
  const TILE_SELS = ["#game_children_challenge a"];
  const NEXT_SEL = 'a[class*="right-arrow"], #game_answerFrame_children_arrowRightContainer, .right-arrow, [aria-label="Navigate to next image"]';
  const PREV_SEL = 'a[class*="left-arrow"], #game_answerFrame_children_arrowLeftContainer, .left-arrow, [aria-label="Navigate to previous image"]';
  const SUBMIT_SEL = '.match-game.box.screen button, #game_children_button, button[type="submit"]';
  const RELOAD_SEL = '[class*="reload"], [aria-label*="reload" i], [aria-label*="refresh" i]';
  const hit = (el, sel) => { try { return el.closest && el.closest(sel); } catch (e) { return null; } };
  const isNext = (el) => !!hit(el, NEXT_SEL);
  const isPrev = (el) => !!hit(el, PREV_SEL);
  const isReload = (el) => !!hit(el, RELOAD_SEL);
  const isSubmit = (el) => !!hit(el, SUBMIT_SEL) && !isNext(el) && !isPrev(el) && !isReload(el);
  function cellIndex(el) {
    for (const s of TILE_SELS) {
      const c = hit(el, s);
      if (c) { const cells = [...document.querySelectorAll(s)]; const i = cells.indexOf(c); if (i >= 0) return i; }
    }
    return -1;
  }

  // ---------- theo doi click (capture-phase: bat ca click do solver KHAC tao ra) ----------
  document.addEventListener("click", (e) => {
    try {
      const el = e.target;
      if (!el || !el.closest) return;
      touch();
      if (isNext(el)) { netClicks++; dlog("click NEXT netClicks=" + netClicks); return; }
      if (isPrev(el)) { netClicks--; dlog("click PREV netClicks=" + netClicks); return; }
      if (isReload(el)) { netClicks = 0; dlog("click RELOAD -> netClicks=0"); return; }
      if (!curImage) refreshDomImage();
      if (isSubmit(el)) {
        let idx = netClicks;
        if (idx < 0) { if (nCells > 1) idx = ((idx % nCells) + nCells) % nCells; else { dlog("SUBMIT skip: netClicks<0, nCells unknown"); netClicks = 0; return; } }
        dlog("click SUBMIT idx=" + idx + " (netClicks=" + netClicks + " N=" + curN + ")");
        buffer(idx, "netclicks");
        netClicks = 0;
        return;
      }
      const ci = cellIndex(el);
      if (ci >= 0) { dlog("click TILE cell=" + ci); buffer(ci, "tile"); return; }
    } catch (err) {}
  }, true);

  // ---------- buffer per-wave (KEY theo N; dedup theo anh; CHUA gan variant) ----------
  function buffer(index, src) {
    if (!curImage || !(index >= 0)) { dlog("buffer SKIP (img=" + (curImage ? "yes" : "NONE") + " idx=" + index + ")"); return; }
    const rec = { n: curN, image: curImage, index: index, src: src || "", variant: variantByN[curN] || null }; // snapshot variant (immune ghi de challenge sau)
    const ex = queue.findIndex((q) => q.image === curImage);
    if (ex >= 0) { queue[ex] = rec; dlog("buffer REPLACE N=" + curN + " idx=" + index + " queue=" + queue.length); }
    else if (queue.length < 24) { queue.push(rec); dlog("buffer NEW N=" + curN + " idx=" + index + " src=" + src + " queue=" + queue.length); }
    else dlog("buffer FULL (24) -> drop");
  }

  // ---------- solved -> JOIN variantByN[N] roi flush (1 lan/dot) ----------
  function doFlush() {
    if (flushed || !queue.length) return;
    flushed = true;
    const batch = queue; queue = [];
    let sent = 0, drop = 0;
    for (const rec of batch) {
      const v = rec.variant || variantByN[rec.n];                 // snapshot truoc, fallback lookup theo N
      if (!v) { drop++; dlog("flush DROP N=" + rec.n + " (chua co variant) idx=" + rec.index); continue; }
      sent++;
      dlog("collect", v, "· N", rec.n, "· idx", rec.index, "· src", rec.src);
      try { chrome.runtime.sendMessage({ action: "fc_collect", rec: { variant: v, image: rec.image, index: rec.index, src: rec.src } }); } catch (e) {}
    }
    dlog("FLUSH sent=" + sent + (drop ? (" · drop=" + drop) : ""));
  }

  // ---------- solved detection du phong (DOM) — solved:true JSON chi ~5% tren game-core 1.36 ----------
  const DONE_RX = /verification complete|proven you'?re a human|continue your action/i;
  const IS_ARKOSE = /arkoselabs|funcaptcha/i.test(location.hostname); // KHONG arm o top roblox.com SPA
  let doneTimer = null;
  function domMatch() { try { const b = document.body; return !!b && DONE_RX.test(b.innerText || b.textContent || ""); } catch (e) { return false; } }
  function curSubmitted() { return !curImage || queue.some((q) => q.image === curImage); } // wave HIEN TAI da submit chua?
  function checkDone() {
    if (doneStale && !domMatch()) doneStale = false;               // clear NGAY khi text sot bien mat (khong doi queue) -> khong ket true qua challenge that
    if (flushed || !queue.length || doneTimer) return;
    if (doneStale) return;                                         // text sot van con -> chua phai solve cua challenge NAY
    if (!domMatch()) return;
    doneTimer = setTimeout(function tick() {
      doneTimer = null;
      if (flushed || !queue.length || !domMatch() || doneStale) return; // timer sot qua ranh gioi challenge -> doneStale=true -> chet, khong flush nham
      // khong flush khi con hoat dong / wave hien tai chua submit (tranh chan wave dang o khe suy nghi solver)
      if (Date.now() - lastAct < 1000 || !curSubmitted()) { doneTimer = setTimeout(tick, 600); return; }
      dlog("solved <- DOM idle-terminal");
      doFlush(); relay({ t: "solved" });
    }, 1200);
  }
  function startWatch() {
    try {
      let pend = false;
      const onMut = () => { if (pend) return; pend = true; setTimeout(() => { pend = false; checkDone(); }, 300); }; // throttle -> tranh innerText reflow moi mutation lam giat solver
      new MutationObserver(onMut).observe(document.body || document.documentElement, { childList: true, subtree: true, characterData: true });
      checkDone();
    } catch (e) {}
  }
  if (IS_ARKOSE) { if (document.body) startWatch(); else document.addEventListener("DOMContentLoaded", startWatch, { once: true }); }

  // Challenge CUOI chuoi (khong co anh ke -> khong rollover) + success-redirect: frame bi teardown truoc khi
  // DOM-idle (~1.5s) kip fire -> mat waves. Flush luc teardown, van gate SOLVED (domMatch) de khong POST
  // dap an sai khi bi abandon. doFlush idempotent (guard flushed) -> khong double-POST.
  function teardownFlush() {
    try { if (!flushed && queue.length && domMatch() && !doneStale) { dlog("teardown flush=" + queue.length); doFlush(); relay({ t: "solved" }); } } catch (e) {}
  }
  window.addEventListener("pagehide", teardownFlush, true);
  document.addEventListener("visibilitychange", () => { if (document.hidden) teardownFlush(); }, true);
})();
