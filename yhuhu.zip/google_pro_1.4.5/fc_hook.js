/*
 * FC Tracker — MAIN-world hook (chay trong frame Arkose/FunCaptcha).
 * QUAN SAT-ONLY: doc du lieu trang roi postMessage cho fc_tracker (isolated). Moi tin hieu deu KEY theo
 * challenge=N (index wave) de fc_tracker JOIN variant<->anh chinh xac, khong lo cheo frame / timing:
 *   - variant : {n:N, variant} — instruction_string/game_variant CUA RIENG round N (challenge_image challenge=N);
 *               round 0 lay tu /fc/gfct game_data. Emit MOI N (khong lay max) -> map {N->variant}.
 *   - image   : {n:N, b64} — /rtig/image?challenge=N (N lay tu URL).
 *   - solved  : /fc/ca tra solved=true -> ca challenge DUNG.
 * KHONG con "reset": /fc/ca per-wave co the mang game_data.instruction_string -> reset moi wave se wipe queue
 * (bug catastrophic). fc_tracker phan doan challenge bang N-rollover + flush, khong can reset.
 */
(() => {
  "use strict";
  try { console.log("%c[fc-hook]%c loaded @ " + location.href.slice(0, 80), "color:#fbbf24;font-weight:bold", ""); } catch (e) {}
  const _parse = JSON.parse;
  const post = (m) => { try { window.postMessage(Object.assign({ __fcq: 1 }, m), "*"); } catch (e) {} };
  const safe = (v) => (typeof v === "string" ? v : "").toLowerCase().replace(/[^a-z0-9_-]/g, "");

  function feed(data) {
    try {
      if (!data || typeof data !== "object") return;
      if (data.solved === true) post({ type: "solved" });
      // round 0: /fc/gfct game_data (khong co challenge_image) -> N=0
      const gd = data.game_data;
      if (gd && typeof gd === "object") {
        const v0 = safe((typeof gd.instruction_string === "string" && gd.instruction_string) || (typeof gd.game_variant === "string" && gd.game_variant) || "");
        if (v0) post({ type: "variant", n: 0, variant: v0 });
      }
      // per-wave: MOI object co instruction_string/game_variant + challenge_image(challenge=N) -> variant cho RIENG N do
      (function walk(o) {
        if (!o || typeof o !== "object") return;
        if (Array.isArray(o)) { for (const x of o) walk(x); return; }
        const ins = (typeof o.instruction_string === "string" && o.instruction_string)
          || (typeof o.game_variant === "string" && o.game_variant) || "";
        const img = o.challenge_image;
        if (ins && typeof img === "string") {
          const m = /challenge=(\d+)/.exec(img);
          if (m) { const f = safe(ins); if (f) post({ type: "variant", n: parseInt(m[1], 10), variant: f }); }
        }
        for (const k in o) walk(o[k]);
      })(data);
    } catch (e) {}
  }

  function grabBlob(blob, url) {
    try {
      const m = /[?&]challenge=(\d+)/.exec(url || "");
      const n = m ? parseInt(m[1], 10) : null;
      const fr = new FileReader();
      fr.onload = () => { const s = String(fr.result || ""); const i = s.indexOf(","); if (i > 0) post({ type: "image", n: n, b64: s.slice(i + 1) }); };
      fr.readAsDataURL(blob);
    } catch (e) {}
  }

  // 1) JSON.parse — game-core thuong parse config bang JSON.parse.
  JSON.parse = function () { const out = _parse.apply(this, arguments); feed(out); return out; };

  // 2) fetch — /rtig/image (anh) + cac /fc/ JSON.
  if (typeof window.fetch === "function") {
    const _fetch = window.fetch;
    window.fetch = function () {
      const a = arguments;
      return _fetch.apply(this, a).then((res) => {
        try {
          const u = (a[0] && (typeof a[0] === "string" ? a[0] : a[0].url)) || res.url || "";
          if (/rtig\/image/.test(u)) res.clone().blob().then((b) => grabBlob(b, u)).catch(() => {});
          else res.clone().text().then((t) => { if (t && (t[0] === "{" || t[0] === "[")) feed(_parse(t)); }).catch(() => {});
        } catch (e) {}
        return res;
      });
    };
  }

  // 3) XHR — /rtig/image (blob/arraybuffer) + JSON/text.
  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function () {
    this.addEventListener("load", function () {
      try {
        const u = this.responseURL || "";
        if (/rtig\/image/.test(u) && (this.responseType === "blob" || this.responseType === "arraybuffer")) {
          grabBlob(this.responseType === "blob" ? this.response : new Blob([this.response]), u);
        } else if (this.responseType === "json" && this.response) { feed(this.response); }
        else if (this.responseType === "" || this.responseType === "text") {
          const t = this.responseText; if (t && t.length < 5e6 && (t[0] === "{" || t[0] === "[")) feed(_parse(t));
        }
      } catch (e) {}
    });
    return _open.apply(this, arguments);
  };

  // 4) postMessage (Roblox HYBRID truyen game data) — bo qua message cua chinh tracker (__fcq).
  window.addEventListener("message", (e) => {
    try {
      let d = e.data;
      if (d && d.__fcq) return;
      if (typeof d === "string" && d.length < 5e6 && (d[0] === "{" || d[0] === "[")) { try { d = _parse(d); } catch (x) {} }
      feed(d);
    } catch (err) {}
  }, true);
})();
